package com.example.samsung.nac_rm78223;

import android.os.AsyncTask;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class Get extends AsyncTask<String,Void,String> {


    private TextView txtTitle;
    private TextView txtCompleted;

    public Get(EditText txtTitle, EditText txtCompleted) {

        this.txtTitle = txtTitle;
        this.txtCompleted = txtCompleted;

    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        String resultado = Comandos.get(url);

        return resultado;
    }

    @Override
    protected void onPostExecute(String s) {

        try{
            JSONObject jsonResponse = new JSONObject(s);

            JSONObject dataResponse = jsonResponse.getJSONObject("data");


            String title = dataResponse.getString("title");
            String completed = dataResponse.getString("completed");

            txtTitle.setText(title);
            txtCompleted.setText(completed);

        }
        catch(JSONException e){
            this.txtTitle.setText("erroJSON");
        }
    }


}
