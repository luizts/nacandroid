package com.example.samsung.nac_rm78223;

import android.os.AsyncTask;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class Post extends AsyncTask<String,Void,String> {

    private TextView txtMensagem;

    public Post(TextView txtMensagem) {

        this.txtMensagem = txtMensagem;
    }

    @Override
    protected String doInBackground(String... strings) {

        return Comandos.Post(strings[0],strings[1]);
    }

    @Override
    protected void onPostExecute(String s) {
        try{
            JSONObject jsonResponse = new JSONObject(s);

            String id = jsonResponse.getString("id");

            String At = jsonResponse.getString("At");


            txtMensagem.setText(id + "" + At);

        }
        catch(JSONException e){
            this.txtMensagem.setText("erroJSON");
        }
    }
}
