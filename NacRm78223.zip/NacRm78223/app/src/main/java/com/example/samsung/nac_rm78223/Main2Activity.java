package com.example.samsung.nac_rm78223;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void executaPost(View view){

        String url = "https://jsonplaceholder.typicode.com/posts/";
        String parameter =  "{\n" +
                "    \"id\": \"testando\",\n" +
                "    \"userId\": \"testando1\",\n" +
                "    \"title\": \"testando11\",\n" +
                "    \"body\": \"1234\"\n" +
                "}";
        TextView txtMensagem = findViewById(R.id.tvResposta);

        new Post(txtMensagem).execute(url,parameter);

    }
}
