package com.example.samsung.nac_rm78223;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {


    public final String PreferenceKey = "PREF";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }

    public void gravaChave(View view){
        EditText txtAnot = findViewById(R.id.edAnotacao);
        addPreference("01",txtAnot.getText().toString());
    }

    public void recuperaPreferencia(View view){
        TextView txtResposta = findViewById(R.id.tvResposta);
        txtResposta.setText(getPreference("01"));
    }

    public void addPreference(String chave,String valor){
        SharedPreferences sh = getSharedPreferences(PreferenceKey, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sh.edit();

        ed.putString(chave,valor);
        ed.apply();
    }

    public String getPreference(String chave){
        SharedPreferences sh = getSharedPreferences(PreferenceKey,Context.MODE_PRIVATE);
        return sh.getString(chave,"");
    }

}
