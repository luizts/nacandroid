package com.example.samsung.nac_rm78223;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void tela2(View v)
    {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }

    public void executaGet(View v){

        String response;
        String url = "https://jsonplaceholder.typicode.com/todos/";

        EditText txtId = findViewById(R.id.txtId);
        url += txtId.getText().toString();

        EditText txtTitle= findViewById(R.id.txtTitle);
        EditText txtCompleted = findViewById(R.id.txtCompleted);




        new Get(txtTitle,txtCompleted).execute(url);


    }


}
